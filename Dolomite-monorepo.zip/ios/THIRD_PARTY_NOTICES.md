# Third-party notices and credits

Dolomite External is developed and distributed under GPL-3.0. It is derived from
**3105**, created and designed by [YangJiii](https://x.com/duongduong0908), and
incorporates ideas, formats, research, or implementation foundations from the
following community work.

| Project/person | Contribution acknowledged by Dolomite External | Upstream |
| --- | --- | --- |
| 0xjohnnydev and FilzaSlop contributors | MHA-C2 app-data discovery and sandbox-escape foundation | [FilzaSlop](https://github.com/0xjohnnydev/FilzaSlop) |
| CrazyMind90 | FilzaSlop sandbox-escape foundation | [GitHub profile](https://github.com/CrazyMind90) |
| LeminLimez and contributors | Pocket Poster, Nugget, and the `.tendies` package format | [Pocket-Poster](https://github.com/leminlimez/Pocket-Poster) |
| forcequitOS | `bad_query` research | [GitHub profile](https://github.com/forcequitOS) |
| opa334 and Dopamine contributors | Kernel-exploit research foundation | [Dopamine](https://github.com/opa334/Dopamine) |

Original portions of 3105 and of Dolomite External are distributed under GPL-3.0.
Pocket-Poster also publishes a GPL-3.0 license in its upstream repository.
FilzaSlop did not expose a repository license through GitHub when this notice was
prepared. Review each upstream project and its current terms before redistributing
derived code.

The GPL-3.0 license applies only to material for which the project owner has the
right to grant that license. This file provides attribution; it does not replace
upstream copyright or license notices and does not relicense third-party material.
