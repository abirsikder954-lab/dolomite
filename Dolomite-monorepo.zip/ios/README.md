# Dolomite External

Dolomite External is an unsigned iOS utility that exposes device-level features on
a jailbroken-free device through an in-app kernel exploit chain:

- **Gestalt Editor** — read and write `MobileGestalt` capability values.
- **App Data Browser** — browse and edit application and system containers.
- **Patch Projects** — encrypted, shareable "function packs" with apply / restore / reset.
- **Repository Marketplace** — signed manifests with SHA-256 verified packages.
- **Wallpaper Lab** — PosterBoard `.tendies` package installation and recovery.
- **Cleaner** — removes `Library/Caches` and `tmp` only.

## Requirements

- iOS 16.0 or newer (kernel exploit verified on iOS 17.x and 18.0–18.7.1).
- An enterprise-signed install. SideStore, AltStore, 3uTools and LiveContainer are
  not supported because the app needs the `com.apple.mobile.MobileHouseArrest`
  bundle identifier to reach other apps' containers.

## Building

```bash
python3 ThreeOneOSFive/scripts/embed-runtime-material.py \
  ThreeOneOSFive/helpers/RuntimeMaterial.generated.swift

xcodebuild \
  -project ThreeOneOSFive.xcodeproj \
  -target dolomiteexternal \
  -configuration Release \
  -sdk iphoneos \
  -xcconfig DolomiteLicensing.xcconfig \
  ARCHS=arm64 ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build
```

Server configuration (license URL, Ed25519 and RSA-3072 public keys, TLS pins)
lives in `DolomiteLicensing.xcconfig`. The `Material` build phase folds it into
`ThreeOneOSFive/helpers/RuntimeMaterial.generated.swift` as obfuscated bytes.

## Checks

```bash
node --test checks/native/check-reflection.test.mjs
bash checks/native/run.sh
```

## License

GPL-3.0. See `LICENSE` and `THIRD_PARTY_NOTICES.md`.
