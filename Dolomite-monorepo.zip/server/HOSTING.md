# হোস্টিং গাইড — VPS ছাড়া GitHub থেকে চালানো

এই ডকুমেন্টে দেখানো হলো **Dolomite External** লাইসেন্স সার্ভার + ড্যাশবোর্ড আর
IPA বিল্ড — দুটোই কীভাবে **VPS ছাড়া** চালাবে।

---

## সংক্ষেপে: কোনটা কোথায় চলবে

| জিনিস | কোথায় | খরচ | ঘুমায়? | GitHub Actions দিয়ে deploy? |
|---|---|---|---|---|
| **IPA বিল্ড** | GitHub Actions (`macos-15`) | ফ্রি | না | এটাই GitHub Actions |
| **সার্ভার** — Cloudflare Worker | Cloudflare Workers | ফ্রি (১০০k req/day) | **না, সবসময় চালু** | ✅ `deploy-worker.yml` |
| **সার্ভার** — Render free | Render | ফ্রি | ১৫ মিনিট পরে ঘুমায় | ✅ `deploy-render.yml` |

**প্রস্তাব:** Cloudflare Worker। কারণ —
- সবসময় চালু থাকে, কোনো cold start নেই (অ্যাপের লাইসেন্স API-তে ৩০ সেকেন্ড টাইমআউট আছে, sleep হলে activation ভেঙে যায়)
- `DolomiteLicensing.xcconfig`-এ যে TLS pin-গুলো আছে **সেগুলো Cloudflare-এর root CA** — তাই কোনো কাজ করতে হবে না
- GitHub Actions থেকে `wrangler deploy` দিয়েই deploy হয়

Render free tier একটু সহজ (কোনো Cloudflare account লাগে না), কিন্তু ঘুমায় — তাই
সেটার জন্য `keep-alive.yml` আছে।

---

## ১. IPA বিল্ড (একদম GitHub-এ, VPS লাগে না)

### সেটআপ

1. iOS রিপোটা GitHub-এ push করো (বা নতুন রিপো বানাও)।
2. Actions ট্যাব খুললেই "Build Dolomite External IPA" দেখবে।

এই ফ্লো **macOS runner**-এ চলে, তাই signing certificate লাগে না — আউটপুট
**unsigned IPA**।

### কীভাবে ট্রিগার হয়

| ইভেন্ট | ফলাফল |
|---|---|
| `main` / `ipa-build` ব্রাঞ্চে push (app ফাইল বদলালে) | IPA বানায় + artifact আপলোড |
| `v1.0.0` ট্যাগ push | IPA বানায় + **GitHub Release** তৈরি হয় (IPA সহ) |
| Actions ট্যাব থেকে "Run workflow" | হাতে বানায় |

### আর্টিফ্যাক্ট কোথায় পাবে

বিল্ড শেষে Actions রানের পেজে **Artifacts** সেকশনে:

```
dolomiteexternal-unsigned-IPA
├── dolomiteexternal-unsigned.ipa
├── SHA256SUMS.txt
└── build-summary.md
```

`build-summary.md`-তে SHA-256 সহ টেবিল থাকে।

### রিলিজ নিতে

```bash
git tag v1.0.0
git push origin v1.0.0
```

এরপর GitHub-এর Releases পেজে `dolomiteexternal-unsigned.ipa` ফাইল পাবে।

### ফ্লো কী কী করে (একটু বিস্তারিত)

```
checkout → xcodebuild -version → cache → node test (reflection metadata)
   → bash checks/native/run.sh (recovery + catalog checks)
   → xcodebuild -target dolomiteexternal -configuration Release -sdk iphoneos
   → error surfacing (grep "error:" + tail 40)
   → node check-reflection.mjs <binary>   ← iOS 16 Combine crash guard
   → ditto + zip → IPA + SHA256
   → upload artifact → (ট্যাগ হলে) GitHub Release
```

বিল্ড fail করলে লগে `error:` লাইনগুলো আলাদা করে দেখায়, তাই আসল কারণ লগের
শেষে লুকিয়ে থাকে না।

---

## ২. সার্ভার — Cloudflare Worker (প্রস্তাব)

### একবারের সেটআপ

```bash
npm install --no-save wrangler@4
npx wrangler login

# KV namespace বানাও
cd worker
npx wrangler kv namespace create DOLOMITE_KV
# → output-এ যে id পাবে, wrangler.toml-এ বসাও
```

এরপর `worker/wrangler.toml`:

```toml
[[kv_namespaces]]
binding = "DOLOMITE_KV"
id = "যে-id-পেলে"
```

সেক্রেট বসাও:

```bash
cd worker
npx wrangler secret put ADMIN_PASSWORD
```

### GitHub-এর Repository secrets

রিপোর **Settings → Secrets and variables → Actions**:

| নাম | টাইপ | মান |
|---|---|---|
| `CLOUDFLARE_API_TOKEN` | Secret | Cloudflare → My Profile → API Tokens → **Create Token** → template **"Edit Cloudflare Workers"** → copy the value |
| `CLOUDFLARE_ACCOUNT_ID` | Secret | Cloudflare → Workers & Pages → তোমার account → ডান পাশে **Account ID** |

> দুটো secret না দিলে `deploy-worker.yml` এখন প্রথম ধাপেই থামে এবং
> ঠিক বলে দেয় কী কী সেট করতে হবে — আগে wrangler-এর generic error দিত।

আর **Settings → Secrets and variables → Actions → Variables**:

| নাম | মান |
|---|---|
| `WORKER_URL` | `https://dolomite-external.<subdomain>.workers.dev` |

### ডিপ্লয়

`main` ব্রাঞ্চে push করলেই `deploy-worker.yml` নিজে থেকে:
1. টেস্ট চালায় (`npm test`)
2. `wrangler deploy` করে
3. লাইভ Worker-এর `/health` স্মোক টেস্ট করে

অথবা Actions থেকে "Run workflow" চাপো।

### প্রথমবার ড্যাশবোর্ড খোলার পর

1. `https://<worker-url>/dashboard` খোলো
2. `ADMIN_PASSWORD` দিয়ে লগইন করো
3. **Configuration** পেজে `.xcconfig` ব্লক কপি করো
4. অ্যাপের `DolomiteLicensing.xcconfig`-এ বসাও:

```
LICENSE_SERVER_BASE_URL = https://dolomite-external.<subdomain>.workers.dev
CONTENT_MANIFEST_PUBLIC_KEY = <ড্যাশবোর্ড দেখাবে>
RESPONSE_RSA3072_PUBLIC_KEY = <ড্যাশবোর্ড দেখাবে>
```

> `LICENSE_SERVER_BASE_URL`-এ পাথ থাকলেও চলবে — অ্যাপ টাউলটে `v1/...` যোগ করে,
> আর সার্ভার `/v1/...` ও `/api/v1/...` দুটোতেই উত্তর দেয়।

### মনে রাখবে

- `data/server-keys.json`-এর মতো **প্রাইভেট কী** Worker-এ KV namespace-এ থাকে।
  KV ডিলিট করলে নতুন কী জেনারেট হবে আর অ্যাপ আর কাজ করবে না।
  ব্যাকআপ নিতে চাইলে:
  ```bash
  npx wrangler kv key list --binding DOLOMITE_KV
  npx wrangler kv key get --binding DOLOMITE_KV server-keys
  ```
- KV eventually consistent — দুই জায়গা থেকে একসাথে একটা key edit করলে একটা
  update হারাতে পারে। একজন ম্যানেজার হলে সমস্যা নেই।

---

## ৩. সার্ভার — Render free (সহজ অপশন)

### সেটআপ

1. [render.com](https://render.com)-এ New → Blueprint → রিপো দেখাও (render.yaml আছে)
2. Render নিজে `ADMIN_PASSWORD` generate করবে — **সেটা কপি করে রাখো**
3. **Settings → Deploys → Deploy Hook** থেকে URL কপি করো → GitHub secret `RENDER_DEPLOY_HOOK`
4. GitHub variable `RENDER_URL` = তোমার service URL

### ঘুমানো ঠেকানো

Render free tier ১৫ মিনিট অ্যাকটিভিটির পরে ঘুমায়। `keep-alive.yml` প্রতি
১০ মিনিটে `/health` পিং করে, তাই সার্ভার জেগে থাকে।

> GitHub Actions-এর cron চাপের সময় ১৫ মিনিট পর্যন্ত দেরি হতে পারে, তাই
> এটা ১০০% নির্ভরযোগ্য নয়। **তাই Cloudflare Worker-ই আসল পছন্দ।**

---

## ৪. GitHub Actions-এ সার্ভার চালানো (self-hosted)

যদি তোমার কাছে একটা মেশিন/ডিভাইস থাকে (VPS না হলেও), তাহলে GitHub
self-hosted runner ব্যবহার করে সার্ভারটা সেখানে চালাতে পারো:

```yaml
# .github/workflows/run-server.yml
name: Run licence server
on:
  workflow_dispatch:
  schedule:
    - cron: '17 */4 * * *'   # প্রতি ৪ ঘণ্টায় রিস্টার্ট

jobs:
  run:
    runs-on: [self-hosted, linux]     # তোমার লেবেল
    timeout-minutes: 360
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '22' }
      - run: npm ci --omit=dev
      - run: node server.js
        env:
          ADMIN_PASSWORD: ${{ secrets.ADMIN_PASSWORD }}
          DATA_DIR: /srv/dolomite-data
```

রিপোর **Settings → Actions → Runners → New self-hosted runner** থেকে লেবেল
বানাও, তারপর মেশিনে `config.sh` চালাও।

---

## ৫. সব workflow এক নজরে

### অ্যাপ রিপো (`ThreeOneOSFive`)

| ফাইল | কী করে |
|---|---|
| `.github/workflows/build-ipa.yml` | macOS-এ unsigned IPA বানায়, artifact + (ট্যাগ হলে) release |

### সার্ভার রিপো (`dolomite-dashboard`)

| ফাইল | কী করে |
|---|---|
| `.github/workflows/deploy-worker.yml` | টেস্ট করে Cloudflare Worker ডিপ্লয় করে, স্মোক টেস্ট |
| `.github/workflows/deploy-render.yml` | টেস্ট করে Render-এর deploy hook ট্রিগার করে |
| `.github/workflows/keep-alive.yml` | প্রতি ১০ মিনিটে `/health` পিং করে (Render-এর জন্য) |

---

## ৬. চেকলিস্ট — ডিপ্লয়ের আগে

- [ ] `ADMIN_PASSWORD` শক্তিশালী করা (default `dolomite` খুব দুর্বল)
- [ ] `PUBLIC_BASE_URL` সেট করা
- [ ] ড্যাশবোর্ড → Configuration → `.xcconfig` কপি করে অ্যাপে বসানো
- [ ] অ্যাপ রিবিল্ড করা (বিল্ড ফেজটা নতুন key embed করে)
- [ ] `data/server-keys.json` / KV namespace ব্যাকআপ নেওয়া
- [ ] অ্যাপে key activate করে দেখা (ড্যাশবোর্ডের Devices পেজে দেখা যাবে)
- [ ] `npm test` চালিয়ে দেখা (২৮টি চেক)

---

## ৭. ট্রাবলশুটিং

**অ্যাপ বলছে "Unavailable" / TLS error**
→ `LICENSE_SERVER_BASE_URL` সঠিক কিনা দেখো, আর সার্ভারের সার্টিফিকেট
Cloudflare-এরটাই হতে হবে (TLS pin-গুলো Cloudflare root CA-তে পিন করা)।
Render ব্যবহার করলে pin-গুলো মিলবে না — তখন নতুন pin বের করে বসাতে হবে।

**অ্যাপ বলছে "This app version is not allowed"**
→ সার্ভার সাইডে allowed build list — সেটা `manifest`/`games`-এ নেই,
বর্তমানে অ্যাপ build যাচাই সার্ভারের কাজ নয়, অ্যাপ নিজেই করে।

**Activation বলছে "Invalid License"**
→ ড্যাশবোর্ডে key টাওলে key টা আছে কিনা দেখো। Key format:
`DOLO-XXXX-XXXX-XXXX-XXXX` (I, O, 0, 1 নেই)।

**Dashboard খুলছে না**
→ Worker: `npx wrangler tail` দিয়ে লগ দেখো।
→ Render: Render-এর Logs ট্যাব দেখো, আর `/health` কাজ করছে কিনা বলো।

**Worker KV খালি দেখাচ্ছে**
→ `npx wrangler kv key list --binding DOLOMITE_KV` — namespace id মিলছে কিনা দেখো।
