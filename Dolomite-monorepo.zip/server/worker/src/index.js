/**
 * Dolomite External — Cloudflare Worker.
 *
 * Serves the licence API, the admin API and the dashboard from one Worker.
 * The dashboard's static files are bound as Workers Static Assets, so only
 * /api/* and /admin/api/* reach this handler.
 *
 * Bindings (see wrangler.toml):
 *   DOLOMITE_KV   KV namespace holding the JSON collections
 *   ASSETS        static asset binding for ../public
 *
 * Secrets (wrangler secret put ADMIN_PASSWORD):
 *   ADMIN_PASSWORD
 */

'use strict';

const { KVStore } = require('../../lib/store.js');
const { KeyRing } = require('../../lib/keyring.js');
const { handleLicenseRequest } = require('../../lib/license-api.js');
const { handleAdminRequest } = require('../../lib/admin-api.js');

let keyRing = null;

function jsonResponse(status, payload, headers = {}) {
  return new Response(JSON.stringify(payload, null, 2), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...headers,
    },
  });
}

async function getKeyRing(env) {
  if (!keyRing) {
    keyRing = new KeyRing(new KVStore(env.DOLOMITE_KV));
    await keyRing.ensure();
  }
  return keyRing;
}

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'Content-Type, Authorization, X-Dolomite-Installation-ID, X-Dolomite-Timestamp, X-Dolomite-Nonce, X-Dolomite-Proof, x-dolomite-k, x-dolomite-product',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
};

module.exports = {
  async fetch(request, env) {
    const url = new URL(request.url);
    const pathname = decodeURIComponent(url.pathname);

    try {
      if (pathname === '/health') {
        return jsonResponse(200, {
          ok: true,
          service: 'dolomite-external',
          runtime: 'cloudflare-worker',
          time: new Date().toISOString(),
        });
      }

      // ---------------------------------------------------------- licence API
      if (pathname.startsWith('/api/v1/')) {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: CORS_HEADERS });
        }
        const ring = await getKeyRing(env);
        const store = new KVStore(env.DOLOMITE_KV);
        const body = request.method === 'GET' || request.method === 'HEAD'
          ? Buffer.alloc(0)
          : Buffer.from(await request.arrayBuffer());
        const headers = {};
        request.headers.forEach((value, key) => {
          headers[key.toLowerCase()] = value;
        });

        const result = await handleLicenseRequest({
          method: request.method,
          pathname,
          query: url.searchParams,
          headers,
          body,
          store,
          keyRing: ring,
        });

        if (result.raw) {
          return new Response(result.body, {
            status: result.status,
            headers: {
              'Content-Type': result.contentType || 'application/octet-stream',
              ...CORS_HEADERS,
              ...(result.headers || {}),
            },
          });
        }
        return jsonResponse(result.status, result.payload, {
          ...CORS_HEADERS,
          ...(result.headers || {}),
        });
      }

      // ------------------------------------------------------------- admin API
      if (pathname.startsWith('/admin/api/')) {
        const ring = await getKeyRing(env);
        const store = new KVStore(env.DOLOMITE_KV);
        const body = request.method === 'GET' || request.method === 'HEAD'
          ? Buffer.alloc(0)
          : Buffer.from(await request.arrayBuffer());
        const headers = {};
        request.headers.forEach((value, key) => {
          headers[key.toLowerCase()] = value;
        });

        const result = await handleAdminRequest({
          method: request.method,
          pathname: pathname.slice('/admin/api'.length),
          query: url.searchParams,
          headers,
          body,
          store,
          keyRing: ring,
          env,
        });
        return jsonResponse(result.status, result.payload, result.headers || {});
      }

      // --------------------------------------------------------- static assets
      if (env.ASSETS) {
        return env.ASSETS.fetch(request);
      }
      return jsonResponse(404, { error: 'not_found', message: 'Unknown endpoint.' });
    } catch (error) {
      console.error('[worker error]', error && error.stack ? error.stack : error);
      return jsonResponse(500, {
        error: 'internal_error',
        message: String((error && error.message) || error),
      });
    }
  },
};
