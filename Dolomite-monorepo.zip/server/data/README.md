# Runtime data

This folder holds the live state of the server:

| File | Contents |
| --- | --- |
| `server-keys.json` | RSA-3072 and Ed25519 key material — **back this up** |
| `keys.json` | licence keys |
| `sessions.json` | live sessions |
| `challenges.json` | pending device challenges |
| `activations.json` | in-flight activations |
| `packages.json` | published function packs |
| `manifest.json` | content manifest served to the app |
| `games.json` | game descriptors |
| `notice.json` | login notice |
| `activity.json` | rolling activity log |

Everything is plain JSON written atomically, so `cp -r data backup/` is a
complete backup.

The folder is git-ignored on purpose: `server-keys.json` contains the private
keys that sign licence responses.
