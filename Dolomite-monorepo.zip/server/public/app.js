/* Dolomite External — dashboard front-end (no framework, no build step) */

'use strict';

const state = {
  page: 'overview',
  keys: [],
  devices: [],
  packages: [],
  config: null,
  overview: null,
  activity: [],
  filters: { q: '', status: 'all' },
};

/* ------------------------------------------------------------------ api */

async function api(path, options = {}) {
  const response = await fetch(`/admin/api${path}`, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }
  if (response.status === 401 && state.page !== 'login') {
    showLogin();
    throw new Error('unauthorized');
  }
  if (!response.ok) {
    throw new Error((payload && payload.message) || `HTTP ${response.status}`);
  }
  return payload;
}

/* ----------------------------------------------------------------- utils */

const $ = (sel) => document.querySelector(sel);

function escapeHTML(value) {
  return String(value === undefined || value === null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function fmtDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: '2-digit',
    hour: '2-digit', minute: '2-digit',
  });
}

function fmtRelative(value) {
  if (!value) return 'never';
  const diff = Date.now() - new Date(value).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

function toast(message, kind = '') {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast ${kind}`;
  el.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.add('hidden'), 2600);
}

function badge(status) {
  const label = { active: 'Active', expired: 'Expired', revoked: 'Revoked' }[status] || status;
  return `<span class="badge ${escapeHTML(status)}">${escapeHTML(label)}</span>`;
}

async function copyText(text, label = 'Copied') {
  try {
    await navigator.clipboard.writeText(text);
    toast(label, 'good');
  } catch {
    const area = document.createElement('textarea');
    area.value = text;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
    toast(label, 'good');
  }
}

/* ----------------------------------------------------------------- modal */

function openModal(title, bodyHTML, onMount) {
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = bodyHTML;
  $('#modal-backdrop').classList.remove('hidden');
  if (onMount) onMount($('#modal-body'));
}

function closeModal() {
  $('#modal-backdrop').classList.add('hidden');
  $('#modal-body').innerHTML = '';
}

$('#modal-close').addEventListener('click', closeModal);
$('#modal-backdrop').addEventListener('click', (event) => {
  if (event.target === $('#modal-backdrop')) closeModal();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeModal();
});

/* ----------------------------------------------------------------- login */

function showLogin() {
  $('#login').classList.remove('hidden');
  $('#app').classList.add('hidden');
}

function showApp() {
  $('#login').classList.add('hidden');
  $('#app').classList.remove('hidden');
}

$('#login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const error = $('#login-error');
  error.classList.add('hidden');
  try {
    await api('/login', { method: 'POST', body: { password: $('#login-password').value } });
    $('#login-password').value = '';
    showApp();
    await loadPage(state.page);
  } catch (problem) {
    error.textContent = problem.message || 'Sign in failed.';
    error.classList.remove('hidden');
  }
});

$('#logout').addEventListener('click', async () => {
  try {
    await api('/logout', { method: 'POST' });
  } catch { /* ignore */ }
  showLogin();
});

/* ------------------------------------------------------------ navigation */

const PAGE_META = {
  overview: ['Overview', 'Licence activity at a glance'],
  keys: ['Licence keys', 'Every key issued for Dolomite External'],
  devices: ['Devices', 'Devices bound to a licence'],
  packages: ['Packages', 'Function packs published to the app'],
  api: ['API reference', 'The endpoints the iOS app calls'],
  settings: ['Configuration', 'Public keys and client settings'],
};

document.querySelectorAll('.nav-item').forEach((button) => {
  button.addEventListener('click', () => loadPage(button.dataset.page));
});

$('#refresh').addEventListener('click', () => loadPage(state.page));

$('#new-key').addEventListener('click', () => {
  openModal('New licence key', `
    <label class="field">
      <span>Label</span>
      <input id="k-label" type="text" placeholder="e.g. Rahim — FF Max" maxlength="120">
    </label>
    <label class="field">
      <span>Plan</span>
      <select id="k-plan">
        <option value="standard">Standard</option>
        <option value="premium">Premium</option>
        <option value="lifetime">Lifetime</option>
        <option value="trial">Trial</option>
      </select>
    </label>
    <label class="field">
      <span>Validity (days)</span>
      <input id="k-days" type="number" value="30" min="1" max="3650">
    </label>
    <label class="field">
      <span>Custom key (optional)</span>
      <input id="k-custom" type="text" placeholder="DOLO-XXXX-XXXX-XXXX-XXXX" maxlength="29">
    </label>
    <button class="btn btn-primary btn-block" id="k-create">Create key</button>
  `, (root) => {
    root.querySelector('#k-create').addEventListener('click', async () => {
      try {
        const created = await api('/keys', {
          method: 'POST',
          body: {
            label: root.querySelector('#k-label').value,
            plan: root.querySelector('#k-plan').value,
            days: Number(root.querySelector('#k-days').value),
            key: root.querySelector('#k-custom').value.trim(),
          },
        });
        closeModal();
        toast(`Key ${created.key.key} created`, 'good');
        await loadPage('keys');
      } catch (problem) {
        toast(problem.message, 'bad');
      }
    });
  });
});

/* ------------------------------------------------------------ page loader */

async function loadPage(page) {
  state.page = page;
  document.querySelectorAll('.nav-item').forEach((b) => {
    b.classList.toggle('active', b.dataset.page === page);
  });
  document.querySelectorAll('.page').forEach((section) => {
    section.classList.toggle('hidden', section.id !== `page-${page}`);
  });
  const [title, sub] = PAGE_META[page] || ['', ''];
  $('#page-title').textContent = title;
  $('#page-sub').textContent = sub;

  try {
    if (page === 'overview') {
      state.overview = await api('/overview');
      renderOverview();
    } else if (page === 'keys') {
      const result = await api(`/keys?q=${encodeURIComponent(state.filters.q)}&status=${state.filters.status}`);
      state.keys = result.keys;
      renderKeys();
    } else if (page === 'devices') {
      const result = await api('/devices');
      state.devices = result.devices;
      renderDevices();
    } else if (page === 'packages') {
      const result = await api('/packages');
      state.packages = result.packages;
      renderPackages();
    } else if (page === 'api') {
      renderApi();
    } else if (page === 'settings') {
      state.config = await api('/config');
      renderSettings();
    }
  } catch (problem) {
    if (problem.message !== 'unauthorized') {
      toast(problem.message, 'bad');
    }
  }
}

/* -------------------------------------------------------------- overview */

function renderOverview() {
  const { stats, activity, recentKeys, expiring } = state.overview;
  const cards = [
    ['Active keys', stats.active, `${stats.total} issued in total`, 'good'],
    ['Expiring in 7 days', stats.expiringSoon, 'Renew before they lapse', stats.expiringSoon ? 'warn' : ''],
    ['Bound devices', stats.bound, `${stats.unbound} not activated yet`, ''],
    ['Activations (24h)', stats.activations24h, `${stats.liveSessions} live sessions`, ''],
  ];

  $('#page-overview').innerHTML = `
    <div class="grid grid-4">
      ${cards.map(([label, value, note, tone]) => `
        <div class="card">
          <div class="stat-label">${escapeHTML(label)}</div>
          <div class="stat-value ${tone}">${escapeHTML(value)}</div>
          <div class="stat-note">${escapeHTML(note)}</div>
        </div>`).join('')}
    </div>

    <div class="grid grid-2">
      <div class="panel">
        <div class="panel-head"><h3>Recent activity</h3></div>
        <div class="panel-body">
          <div class="feed">
            ${activity.length ? activity.map(feedItem).join('') : '<div class="empty">No activity yet.</div>'}
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-head"><h3>Expiring soon</h3></div>
        <div class="table-wrap">
          ${expiring.length ? `
            <table>
              <thead><tr><th>Key</th><th>Label</th><th>Expires</th></tr></thead>
              <tbody>
                ${expiring.map((k) => `
                  <tr>
                    <td class="key-text">${escapeHTML(k.maskedKey)}</td>
                    <td>${escapeHTML(k.label || '—')}</td>
                    <td>${escapeHTML(fmtDate(k.expiresAt))}</td>
                  </tr>`).join('')}
              </tbody>
            </table>` : '<div class="empty">Nothing expires in the next 7 days.</div>'}
        </div>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Newest keys</h3></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Key</th><th>Label</th><th>Plan</th><th>Status</th><th>Device</th><th>Expires</th></tr></thead>
          <tbody>
            ${recentKeys.map(keyRow).join('') || '<tr><td colspan="6"><div class="empty">No keys issued yet.</div></td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function feedItem(entry) {
  const tone = entry.type.includes('completed') ? 'good'
    : entry.type.includes('rejected') || entry.type.includes('revoke') ? 'bad'
      : entry.type.includes('started') ? 'warn' : '';
  return `
    <div class="feed-item">
      <span class="feed-dot ${tone}"></span>
      <span>${escapeHTML(describeActivity(entry))}</span>
      <span class="feed-time">${escapeHTML(fmtRelative(entry.at))}</span>
    </div>`;
}

function describeActivity(entry) {
  const map = {
    'activation.started': () => `Activation started on ${entry.device || 'a device'}`,
    'activation.completed': () => `Licence activated on ${entry.device || 'a device'}`,
    'activation.rejected': () => `Activation rejected — ${entry.reason || 'invalid key'}`,
    'permit.issued': () => `Write permit issued for ${entry.package || 'a package'} (${entry.action || 'apply'})`,
  };
  return (map[entry.type] || (() => entry.type))();
}

/* ------------------------------------------------------------------ keys */

function keyRow(key) {
  const device = key.device
    ? `<span class="badge bound">${escapeHTML(key.device.model || 'bound')}</span>`
    : '<span class="badge unbound">not bound</span>';
  return `
    <tr>
      <td class="key-text">${escapeHTML(key.key)}</td>
      <td>${escapeHTML(key.label || '—')}</td>
      <td>${escapeHTML(key.plan)}</td>
      <td>${badge(key.status)}</td>
      <td>${device}</td>
      <td>${escapeHTML(fmtDate(key.expiresAt))}</td>
      <td>
        <div class="row-actions">
          <button class="btn btn-ghost btn-sm" data-act="copy" data-key="${escapeHTML(key.key)}">Copy</button>
          <button class="btn btn-ghost btn-sm" data-act="extend" data-id="${escapeHTML(key.id)}">Extend</button>
          <button class="btn btn-ghost btn-sm" data-act="menu" data-id="${escapeHTML(key.id)}">⋯</button>
        </div>
      </td>
    </tr>`;
}

function renderKeys() {
  $('#page-keys').innerHTML = `
    <div class="toolbar">
      <input id="key-search" type="search" placeholder="Search key, label or device…" value="${escapeHTML(state.filters.q)}">
      <select id="key-status">
        ${['all', 'active', 'expired', 'revoked'].map((s) =>
          `<option value="${s}" ${state.filters.status === s ? 'selected' : ''}>${s === 'all' ? 'All statuses' : s}</option>`).join('')}
      </select>
      <span class="muted">${state.keys.length} shown</span>
    </div>
    <div class="panel">
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Key</th><th>Label</th><th>Plan</th><th>Status</th><th>Device</th><th>Expires</th><th></th></tr>
          </thead>
          <tbody>
            ${state.keys.map(keyRow).join('') || '<tr><td colspan="7"><div class="empty"><strong>No keys found</strong>Create one with “+ New key”.</div></td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  const search = $('#key-search');
  let timer = null;
  search.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      state.filters.q = search.value;
      loadPage('keys');
    }, 260);
  });
  $('#key-status').addEventListener('change', (event) => {
    state.filters.status = event.target.value;
    loadPage('keys');
  });

  $('#page-keys').addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-act]');
    if (!button) return;
    const { act, id, key } = button.dataset;

    if (act === 'copy') {
      copyText(key, 'Key copied');
      return;
    }
    if (act === 'extend') {
      openModal('Extend licence', `
        <label class="field">
          <span>Additional days</span>
          <input id="x-days" type="number" value="30" min="1" max="3650">
        </label>
        <button class="btn btn-primary btn-block" id="x-go">Extend</button>
      `, (root) => {
        root.querySelector('#x-go').addEventListener('click', async () => {
          try {
            await api(`/keys/${encodeURIComponent(id)}/extend`, {
              method: 'POST',
              body: { days: Number(root.querySelector('#x-days').value) },
            });
            closeModal();
            toast('Licence extended', 'good');
            loadPage('keys');
          } catch (problem) {
            toast(problem.message, 'bad');
          }
        });
      });
      return;
    }
    if (act === 'menu') {
      const entry = state.keys.find((k) => k.id === id);
      openModal(entry.key, `
        <label class="field">
          <span>Label</span>
          <input id="m-label" type="text" value="${escapeHTML(entry.label || '')}" maxlength="120">
        </label>
        <label class="field">
          <span>Notes</span>
          <input id="m-notes" type="text" value="${escapeHTML(entry.notes || '')}" maxlength="500">
        </label>
        <div class="grid grid-2" style="gap:9px;margin-bottom:14px">
          <button class="btn btn-ghost" id="m-unbind">Unbind device</button>
          <button class="btn btn-ghost" id="m-toggle">${entry.status === 'revoked' ? 'Restore' : 'Revoke'}</button>
        </div>
        <div class="grid grid-2" style="gap:9px">
          <button class="btn btn-danger" id="m-delete">Delete key</button>
          <button class="btn btn-primary" id="m-save">Save changes</button>
        </div>
      `, (root) => {
        root.querySelector('#m-save').addEventListener('click', async () => {
          try {
            await api(`/keys/${encodeURIComponent(id)}`, {
              method: 'PATCH',
              body: { label: root.querySelector('#m-label').value, notes: root.querySelector('#m-notes').value },
            });
            closeModal();
            toast('Saved', 'good');
            loadPage('keys');
          } catch (problem) {
            toast(problem.message, 'bad');
          }
        });
        root.querySelector('#m-unbind').addEventListener('click', async () => {
          try {
            await api(`/keys/${encodeURIComponent(id)}/unbind`, { method: 'POST' });
            closeModal();
            toast('Device unbound', 'good');
            loadPage('keys');
          } catch (problem) {
            toast(problem.message, 'bad');
          }
        });
        root.querySelector('#m-toggle').addEventListener('click', async () => {
          const action = entry.status === 'revoked' ? 'restore' : 'revoke';
          try {
            await api(`/keys/${encodeURIComponent(id)}/${action}`, { method: 'POST' });
            closeModal();
            toast(action === 'revoke' ? 'Licence revoked' : 'Licence restored', 'good');
            loadPage('keys');
          } catch (problem) {
            toast(problem.message, 'bad');
          }
        });
        root.querySelector('#m-delete').addEventListener('click', async () => {
          try {
            await api(`/keys/${encodeURIComponent(id)}`, { method: 'DELETE' });
            closeModal();
            toast('Key deleted', 'good');
            loadPage('keys');
          } catch (problem) {
            toast(problem.message, 'bad');
          }
        });
      });
    }
  });
}

/* --------------------------------------------------------------- devices */

function renderDevices() {
  $('#page-devices').innerHTML = `
    <div class="panel">
      <div class="panel-head"><h3>Bound devices</h3><span class="muted">${state.devices.length} devices</span></div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Device</th><th>iOS</th><th>Build</th><th>Licence</th><th>Status</th><th>Bound</th><th>Last seen</th></tr>
          </thead>
          <tbody>
            ${state.devices.map((d) => `
              <tr>
                <td>${escapeHTML(d.model || d.installationID)}</td>
                <td>${escapeHTML(d.systemVersion || '—')}</td>
                <td>${escapeHTML(d.systemBuild || '—')}</td>
                <td class="key-text">${escapeHTML(d.key)}</td>
                <td>${badge(d.status)}</td>
                <td>${escapeHTML(fmtDate(d.boundAt))}</td>
                <td>${escapeHTML(fmtRelative(d.lastSeenAt))}</td>
              </tr>`).join('') || '<tr><td colspan="7"><div class="empty"><strong>No devices bound</strong>Devices appear here after a client activates a key.</div></td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

/* -------------------------------------------------------------- packages */

function renderPackages() {
  $('#page-packages').innerHTML = `
    <div class="toolbar">
      <button class="btn btn-primary" id="p-add">+ Add package</button>
      <span class="muted">${state.packages.length} published</span>
    </div>
    <div class="panel">
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Name</th><th>Identifier</th><th>Version</th><th>Game</th><th>Size</th><th>SHA-256</th><th></th></tr>
          </thead>
          <tbody>
            ${state.packages.map((p) => `
              <tr>
                <td>${escapeHTML(p.name || p.identifier)}</td>
                <td class="key-text">${escapeHTML(p.identifier)}</td>
                <td>${escapeHTML(p.version)}</td>
                <td>${escapeHTML(p.game || '—')}</td>
                <td>${escapeHTML(p.size ? `${(p.size / 1024).toFixed(1)} KB` : '—')}</td>
                <td class="key-text">${escapeHTML((p.sha256 || '').slice(0, 16))}…</td>
                <td><div class="row-actions"><button class="btn btn-danger btn-sm" data-del="${escapeHTML(p.id)}">Delete</button></div></td>
              </tr>`).join('') || '<tr><td colspan="7"><div class="empty"><strong>No packages</strong>Add function packs the app can download.</div></td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  $('#p-add').addEventListener('click', () => {
    openModal('Add package', `
      <label class="field"><span>Name</span><input id="p-name" type="text" placeholder="Aim assist"></label>
      <label class="field"><span>Identifier</span><input id="p-id" type="text" placeholder="com.dolomite.pkg.aim"></label>
      <label class="field"><span>Version</span><input id="p-ver" type="text" value="1.0.0"></label>
      <label class="field"><span>Game slug</span><input id="p-game" type="text" placeholder="free-fire"></label>
      <label class="field"><span>File name</span><input id="p-file" type="text" placeholder="aim.dolomite"></label>
      <label class="field"><span>SHA-256</span><input id="p-sha" type="text" placeholder="64 hex characters"></label>
      <label class="field"><span>Download URL</span><input id="p-url" type="text" placeholder="https://…/aim.dolomite"></label>
      <button class="btn btn-primary btn-block" id="p-go">Add package</button>
    `, (root) => {
      root.querySelector('#p-go').addEventListener('click', async () => {
        try {
          await api('/packages', {
            method: 'POST',
            body: {
              name: root.querySelector('#p-name').value,
              identifier: root.querySelector('#p-id').value,
              version: root.querySelector('#p-ver').value,
              game: root.querySelector('#p-game').value,
              fileName: root.querySelector('#p-file').value,
              sha256: root.querySelector('#p-sha').value,
              url: root.querySelector('#p-url').value,
            },
          });
          closeModal();
          toast('Package added', 'good');
          loadPage('packages');
        } catch (problem) {
          toast(problem.message, 'bad');
        }
      });
    });
  });

  $('#page-packages').addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-del]');
    if (!button) return;
    try {
      await api(`/packages/${encodeURIComponent(button.dataset.del)}`, { method: 'DELETE' });
      toast('Package removed', 'good');
      loadPage('packages');
    } catch (problem) {
      toast(problem.message, 'bad');
    }
  });
}

/* ------------------------------------------------------------- API page */

const API_ENDPOINTS = [
  {
    method: 'POST', path: '/v1/activation/start', desc: 'Begin a device activation',
    body: {
      license_key: 'DOLO-XXXX-XXXX-XXXX-XXXX',
      device_model: 'iPhone16,2',
      system_version: '18.7.1',
      system_build: '22H100',
      app_version: '4.0',
      app_build: '4',
      installation_id: '5b0f…-…',
      device_hwid: '…',
      public_key: 'base64 raw P-256 point',
      public_key_format: 'p256-x963-base64',
    },
    response: {
      activation_id: '…', poll_token: '…',
      challenge_id: '…', challenge: 'base64 random bytes',
    },
  },
  {
    method: 'POST', path: '/v1/activation/status', desc: 'Finish activation with the device proof',
    body: {
      activation_id: '…', poll_token: '…', installation_id: '…',
      challenge_id: '…', proof_signature: 'base64 ECDSA DER',
      proof_signature_format: 'ecdsa-p256-sha256-der-base64',
    },
    response: { status: 'active', credentials: { access_token: '…', refresh_token: '…', profile: {} } },
  },
  {
    method: 'POST', path: '/v1/session/challenge', desc: 'Request a proof challenge',
    body: { installation_id: '…', credential_type: 'access' },
    response: { challenge_id: '…', challenge: '…' },
  },
  {
    method: 'POST', path: '/v1/session/validate', desc: 'Exchange a proof for fresh credentials',
    body: { installation_id: '…', challenge_id: '…', proof_signature: '…' },
    response: { access_token: '…', refresh_token: '…', access_expires_at: '…', profile: {} },
  },
  {
    method: 'POST', path: '/v1/session/refresh', desc: 'Rotate an expiring session',
    body: { installation_id: '…', challenge_id: '…', proof_signature: '…' },
    response: { access_token: '…', refresh_token: '…', access_expires_at: '…', profile: {} },
  },
  {
    method: 'POST', path: '/v1/session/lease', desc: 'Short-lived operation lease',
    body: {}, response: { lease: '…', expires_at: 'ISO-8601' },
  },
  {
    method: 'POST', path: '/v1/session/permit', desc: 'Signed permit for one write',
    body: {
      request_id: 'uuid', package_id: '…', sha256: '…',
      action: 'apply', app_version: '4.0', app_build: '4',
    },
    response: { permit_base64: '…', signature: 'base64 Ed25519' },
  },
  {
    method: 'GET', path: '/v1/content/latest', desc: 'Signed content manifest',
    body: null,
    response: { manifest_base64: '…', signature: 'base64 Ed25519 (64 bytes)', games: [] },
  },
  {
    method: 'POST', path: '/v1/dolomite/notice', desc: 'Login-screen announcement (plain JSON)',
    body: null,
    response: { enabled: true, message: 'Welcome back', url: 'https://…' },
  },
];

function jsonBlock(value) {
  return escapeHTML(JSON.stringify(value, null, 2));
}

function renderApi() {
  $('#page-api').innerHTML = `
    <div class="note">
      <strong>Transport.</strong> Every <code>/v1/*</code> endpoint except the notice uses the
      encrypted envelope: the request body is <code>{"v":1,"k":…,"n":…,"p":…}</code> where
      <code>k</code> is the AES-256 key wrapped with RSA-OAEP-SHA256 and <code>p</code> is
      AES-256-GCM ciphertext. Responses are
      <code>{"v":1,"k":…,"n":…,"p":…,"s":…}</code> where <code>s</code> is an RSA-PSS-SHA256
      signature over <code>0x01 || nonce || payload</code>.
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Request headers</h3></div>
      <div class="panel-body">
        <dl class="kv">
          <dt>Authorization</dt><dd>Bearer &lt;access token or refresh token&gt;</dd>
          <dt>X-Dolomite-Installation-ID</dt><dd>The device installation UUID</dd>
          <dt>X-Dolomite-Timestamp</dt><dd>Unix seconds, must be within 5 minutes</dd>
          <dt>X-Dolomite-Nonce</dt><dd>Unique per request</dd>
          <dt>X-Dolomite-Proof</dt><dd>ECDSA P-256 signature of the canonical request</dd>
          <dt>x-dolomite-k</dt><dd>Base64 RSA-OAEP wrapped AES key for the response</dd>
          <dt>x-dolomite-product</dt><dd>Always <code>dolomite</code></dd>
        </dl>
        <p class="muted" style="margin-top:12px">
          The proof message is <code>METHOD\npath?query\ninstallation_id\ntimestamp\nnonce</code>,
          optionally followed by <code>body-sha256\n&lt;hash&gt;</code> when the body is bound.
        </p>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Endpoints</h3></div>
      <div class="panel-body">
        ${API_ENDPOINTS.map((endpoint, index) => `
          <div class="api-endpoint" data-index="${index}">
            <div class="api-head">
              <span class="api-method ${endpoint.method.toLowerCase()}">${endpoint.method}</span>
              <span class="api-path">${escapeHTML(endpoint.path)}</span>
              <span class="api-desc">${escapeHTML(endpoint.desc)}</span>
            </div>
            <div class="api-body">
              ${endpoint.body ? `<h4 class="muted" style="margin:0 0 7px">Request</h4><pre class="code">${jsonBlock(endpoint.body)}</pre>` : ''}
              <h4 class="muted" style="margin:0 0 7px">Response</h4>
              <pre class="code">${jsonBlock(endpoint.response)}</pre>
              <button class="btn btn-ghost btn-sm" data-copy-endpoint="${index}">Copy as JSON</button>
            </div>
          </div>`).join('')}
      </div>
    </div>
  `;

  $('#page-api').addEventListener('click', (event) => {
    const head = event.target.closest('.api-head');
    if (head) {
      head.parentElement.classList.toggle('open');
      return;
    }
    const copy = event.target.closest('button[data-copy-endpoint]');
    if (copy) {
      const endpoint = API_ENDPOINTS[Number(copy.dataset.copyEndpoint)];
      copyText(JSON.stringify({ method: endpoint.method, path: endpoint.path, request: endpoint.body, response: endpoint.response }, null, 2), 'Endpoint copied');
    }
  });
}

/* ------------------------------------------------------------- settings */

async function renderSettings() {
  const notice = await api('/notice');
  $('#page-settings').innerHTML = `
    <div class="panel">
      <div class="panel-head"><h3>Client configuration</h3><span class="muted">generated ${escapeHTML(fmtDate(state.config.keyCreatedAt))}</span></div>
      <div class="panel-body">
        <div class="note">
          Paste this into <code>DolomiteLicensing.xcconfig</code> in the app repo, then rebuild.
          The private keys never leave the server — only the public halves travel.
        </div>
        <pre class="code" id="xcconfig-block">${escapeHTML(state.config.xcconfig)}</pre>
        <button class="btn btn-primary btn-sm" id="copy-xcconfig">Copy .xcconfig</button>

        <div class="grid grid-2" style="margin-top:18px">
          <div>
            <div class="stat-label">Base URL</div>
            <p class="muted" style="font-family:ui-monospace,Menlo,monospace">${escapeHTML(state.config.baseURL)}</p>
          </div>
          <div>
            <div class="stat-label">Node runtime</div>
            <p class="muted">${escapeHTML(state.config.node)}</p>
          </div>
        </div>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Public keys</h3></div>
      <div class="panel-body">
        <label class="field">
          <span>RSA-3072 public key (SPKI DER, base64)</span>
          <textarea id="rsa-out" rows="4" readonly>${escapeHTML(state.config.rsaPublic)}</textarea>
        </label>
        <label class="field">
          <span>Ed25519 public key (raw, base64)</span>
          <textarea id="ed-out" rows="2" readonly>${escapeHTML(state.config.ed25519Public)}</textarea>
        </label>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Login notice</h3></div>
      <div class="panel-body">
        <label class="field">
          <span>Enabled</span>
          <select id="n-enabled">
            <option value="true" ${notice.notice.enabled ? 'selected' : ''}>Yes</option>
            <option value="false" ${!notice.notice.enabled ? 'selected' : ''}>No</option>
          </select>
        </label>
        <label class="field"><span>Message</span><input id="n-message" type="text" value="${escapeHTML(notice.notice.message || '')}"></label>
        <label class="field"><span>Link</span><input id="n-url" type="text" value="${escapeHTML(notice.notice.url || '')}"></label>
        <button class="btn btn-primary" id="n-save">Save notice</button>
      </div>
    </div>
  `;

  $('#copy-xcconfig').addEventListener('click', () => copyText(state.config.xcconfig, 'xcconfig copied'));
  $('#n-save').addEventListener('click', async () => {
    try {
      await api('/notice', {
        method: 'PUT',
        body: {
          enabled: $('#n-enabled').value === 'true',
          message: $('#n-message').value,
          url: $('#n-url').value,
        },
      });
      toast('Notice saved', 'good');
    } catch (problem) {
      toast(problem.message, 'bad');
    }
  });
}

/* ------------------------------------------------------------------ boot */

(async function boot() {
  try {
    await api('/overview');
    showApp();
    await loadPage('overview');
  } catch {
    showLogin();
  }
})();
